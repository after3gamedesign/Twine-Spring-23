function respond_click() {
  let name=prompt("What is your name?")
  prompt("Hi "+name+".")
  response_div()
}
let e=document.getElementById("div")
function response_div() {
  if (name !==null) { 
    e.innerHTML=name+" is the best."
  }
}